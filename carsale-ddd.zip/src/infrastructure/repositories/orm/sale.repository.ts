import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CreateSaleDto } from '../../../application/dto/sale/create-sale.dto';
import { UpdateSaleDto } from '../../../application/dto/sale/update-sale.dto';
import { Sale } from '../../../domain/entities/sale.entity';
import { SaleRepository } from '../../../domain/repositories/sale.repository';
import { SaleEntity } from '../../database/entities/sale.entity';

export class SaleOrmRepository implements SaleRepository {
  constructor(
    @InjectRepository(SaleEntity) private repository: Repository<SaleEntity>,
  ) {}

  async findAll(): Promise<Sale[]> {
    const dbSales = await this.repository.find();
    return dbSales.map(this.toDomainEntity);
  }
  async findById(id: number): Promise<Sale> {
    const dbSale = await this.repository.findOne({ where: { id } });
    return this.toDomainEntity(dbSale);
  }
  async create(car: CreateSaleDto): Promise<Sale> {
    const dbSale = await this.repository.save(car);
    await this.repository.save(dbSale);
    return this.toDomainEntity(dbSale);
  }
  async delete(id: number): Promise<void> {
    const dbSale = await this.repository.findOne({ where: { id } });
    await this.repository.remove(dbSale);
  }
  async update(id: number, car: UpdateSaleDto): Promise<Sale> {
    await this.repository.update({ id }, car);
    const updatedSale = await this.repository.findOne({ where: { id } });
    return this.toDomainEntity(updatedSale);
  }

  private toDomainEntity(sale: SaleEntity): Sale {
    return new Sale(
      sale.id,
      sale.car.id,
      sale.client.id,
      sale.salesperson.id,
      sale.price,
      sale.discount,
      sale.createdAt,
      sale.updatedAt,
    );
  }
}
