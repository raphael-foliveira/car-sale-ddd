import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
} from '@nestjs/common';
import { ClientUseCases } from '../../application/use-cases/client.use-cases';
import { CreateClientDto } from '../../application/dto/client/create-client.dto';

@Controller('clients')
export class ClientController {
  constructor(private clientUseCases: ClientUseCases) {}

  @Get()
  findAll() {
    return this.clientUseCases.findAll();
  }

  @Get(':id')
  findById(@Param() id: number) {
    return this.clientUseCases.findById(id);
  }

  @Post()
  create(@Body() @Body() client: CreateClientDto) {
    return this.clientUseCases.create(client);
  }

  @Put(':id')
  update(@Param() id: number, @Body() client: CreateClientDto) {
    return this.clientUseCases.update(id, client);
  }

  @Delete(':id')
  delete(@Param() id: number) {
    return this.clientUseCases.delete(id);
  }
}
