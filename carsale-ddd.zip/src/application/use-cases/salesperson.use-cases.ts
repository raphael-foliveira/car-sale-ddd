import { Inject, Injectable } from '@nestjs/common';
import { SalespersonRepository } from '../../domain/repositories/salesperson.repository';
import { CreateSalesPersonDto } from '../dto/salesperson/create-salesperson.dto';
import { UpdateSalesPersonDto } from '../dto/salesperson/update-salesperson.dto';

@Injectable()
export class SalespersonUseCases {
  constructor(
    @Inject('SalespersonRepository') private repository: SalespersonRepository,
  ) {}

  findAll() {
    return this.repository.findAll();
  }

  findById(id: number) {
    return this.repository.findById(id);
  }

  create(car: CreateSalesPersonDto) {
    return this.repository.create(car);
  }

  delete(id: number) {
    return this.repository.delete(id);
  }

  update(id: number, car: UpdateSalesPersonDto) {
    return this.repository.update(id, car);
  }
}
