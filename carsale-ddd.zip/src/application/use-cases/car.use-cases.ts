import { Inject, Injectable } from '@nestjs/common';
import { CarRepository } from '../../domain/repositories/car.repository';
import { CreateCarDto } from '../dto/car/create-car.dto';
import { UpdateCarDto } from '../dto/car/update-car.dto';

@Injectable()
export class CarUseCases {
  constructor(@Inject('CarRepository') private repository: CarRepository) {}

  findAll() {
    return this.repository.findAll();
  }

  findById(id: number) {
    return this.repository.findById(id);
  }

  create(car: CreateCarDto) {
    return this.repository.create(car);
  }

  delete(id: number) {
    return this.repository.delete(id);
  }

  update(id: number, car: UpdateCarDto) {
    return this.repository.update(id, car);
  }
}
