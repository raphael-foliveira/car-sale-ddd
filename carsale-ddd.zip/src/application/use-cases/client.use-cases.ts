import { Inject, Injectable } from '@nestjs/common';
import { ClientRepository } from '../../domain/repositories/client.repository';
import { CreateClientDto } from '../dto/client/create-client.dto';
import { UpdateClientDto } from '../dto/client/update-client.dto';

@Injectable()
export class ClientUseCases {
  constructor(
    @Inject('ClientRepository') private repository: ClientRepository,
  ) {}
  findAll() {
    return this.repository.findAll();
  }

  findById(id: number) {
    return this.repository.findById(id);
  }

  create(client: CreateClientDto) {
    return this.repository.create(client);
  }

  delete(id: number) {
    return this.repository.delete(id);
  }

  update(id: number, client: UpdateClientDto) {
    return this.repository.update(id, client);
  }
}
