import { CreateSalesPersonDto } from './create-salesperson.dto';

export interface UpdateSalesPersonDto extends Partial<CreateSalesPersonDto> {}
