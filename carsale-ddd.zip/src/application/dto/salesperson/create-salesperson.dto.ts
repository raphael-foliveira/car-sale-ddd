export interface CreateSalesPersonDto {
  name: string;
  email: string;
  password: string;
  phone: string;
  nationalId: string;
  address: string;
  city: string;
  state: string;
  country: string;
  createdAt: Date;
  updatedAt: Date;
}
