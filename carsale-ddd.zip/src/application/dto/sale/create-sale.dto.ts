export interface CreateSaleDto {
  id: number;
  carId: number;
  clientId: number;
  salesPersonId: number;
  price: number;
  discount: number;
  createdAt: Date;
  updatedAt: Date;
}
