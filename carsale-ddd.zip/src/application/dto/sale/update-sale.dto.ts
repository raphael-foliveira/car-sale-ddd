import { CreateSaleDto } from './create-sale.dto';

export interface UpdateSaleDto extends Partial<CreateSaleDto> {}
