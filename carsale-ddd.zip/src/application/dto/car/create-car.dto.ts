export interface CreateCarDto {
  brand: string;
  color: string;
  model: string;
  year: number;
  price: number;
}
